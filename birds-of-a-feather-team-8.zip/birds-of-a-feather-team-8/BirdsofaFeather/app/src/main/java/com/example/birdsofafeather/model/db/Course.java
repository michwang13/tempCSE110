package com.example.birdsofafeather.model.db;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.example.birdsofafeather.model.ICourse;

@Entity(tableName = "courses")
public class Course implements ICourse {
    public Course(int courseId, String year, String quarter, String subject, String courseNum) {
        this.courseId = courseId;
        this.year = year;
        this.quarter = quarter;
        this.subject = subject;
        this.courseNum = courseNum;
    }
    @PrimaryKey
    @ColumnInfo(name="id")
    public int courseId;

    @ColumnInfo(name="year")
    public String year;

    @ColumnInfo(name="quarter")
    public String quarter;

    @ColumnInfo(name="subject")
    public String subject;

    @ColumnInfo(name="courseNum")
    public String courseNum;

    @Override
    public int getId(){
        return this.courseId;
    }

    @Override
    public String getYear() {
        return this.year;
    }

    @Override
    public String getQuarter() {
        return this.quarter;
    }

    @Override
    public String getSubject() {
        return this.subject;
    }

    @Override
    public String getCourseNum() {
        return this.courseNum;
    }
}
