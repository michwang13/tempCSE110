package com.example.birdsofafeather.model;

public interface ICourse {
    int getId();
    String getYear();
    String getQuarter();
    String getSubject();
    String getCourseNum();
}
