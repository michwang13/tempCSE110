package com.example.birdsofafeather.model.db;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Transaction;

import java.util.List;

@Dao
public interface CoursesDao {
    @Transaction
    @Query("SELECT * FROM courses")
    List<Course> getAll();

    @Query("SELECT COUNT(*) from courses")
    int count();
    //not including the person having the classes yet

    @Insert
    void insert(Course course);
}
