package com.example.birdsofafeather;


import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.view.View.OnKeyListener;
import android.view.View;
import android.view.KeyEvent;
import android.widget.Toast;

import com.example.birdsofafeather.model.DummyCourse;
import com.example.birdsofafeather.model.ICourse;
import com.example.birdsofafeather.model.db.AppDatabase;
import com.example.birdsofafeather.model.db.Course;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class EnterClassInfo extends AppCompatActivity {
    private AppDatabase db;

    protected RecyclerView coursesRecyclerView;
    protected RecyclerView.LayoutManager coursesLayoutManager;
    protected CoursesViewAdapter coursesViewAdapter;

//    private ICourse[] data = {
//        new DummyCourse(0, "2001", "Winter", "Software Engineering", "CSE110"),
//        new DummyCourse(1, "2001", "Spring", "Design and Analysis of Algorithms", "CSE101"),
//        new DummyCourse(2, "2001", "Fall", "Econ", "ECON1")};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_class_info);
        //Sets the title bar to Enter Class Info
        setTitle("Enter Class Info");

        Spinner spinner = (Spinner) findViewById(R.id.year_spinner);
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.year_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapter);

        Spinner spinner2 = (Spinner) findViewById(R.id.quarter_spinner);
        // Set ArrayAdapter using the string array and a default spinner layout
        adapter = ArrayAdapter.createFromResource(this,
                R.array.quarter_array, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner2.setAdapter(adapter);


        db = AppDatabase.singleton(this);
        List<Course> courses = db.coursesDao().getAll();

        coursesRecyclerView = findViewById(R.id.courses_view);

        coursesLayoutManager = new LinearLayoutManager(this);
        coursesRecyclerView.setLayoutManager(coursesLayoutManager);

        coursesViewAdapter = new CoursesViewAdapter(courses);
        coursesRecyclerView.setAdapter(coursesViewAdapter);

    }

    //Shows alerts
    public static void showAlert(Activity activity, String message) {
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(activity);

        alertBuilder
                .setTitle("Alert!")
                .setMessage(message)
                .setPositiveButton("Ok", (dialog, id) -> {
                    dialog.cancel();
                })
                .setCancelable(true);

        AlertDialog alertDialog = alertBuilder.create();
        alertDialog.show();
    }

    //Returns true if all the fields are filled out, false otherwise
    public boolean filledOut(Course course) {
        if (course.getSubject().equals("") ||
            course.getCourseNum().equals("") ||
            course.getYear().equals("Year") ||
            course.getQuarter().equals("Quarter")){
            return false;
        }
        return true;

    }

    //Return true if there is a duplicate entry, false otherwise
    public boolean duplicateEntry(Course course) {
        //@Michael, implement this method by checking if the list
        // already contains the current entry
        List<Course> allCourses = db.coursesDao().getAll();

        for (int i = 0; i < allCourses.size(); i++){
            Course tempCourse = allCourses.get(i);
            if (tempCourse.getYear().equals(course.getYear()) &&
                tempCourse.getQuarter().equals(course.getQuarter()) &&
                tempCourse.getSubject().equals(course.getSubject()) &&
                tempCourse.getCourseNum().equals(course.getCourseNum())){
                return true;
            }
        }
        return false;
    }


    public void onEnterBtnClicked(View view) {
        EditText subject = (EditText) findViewById(R.id.editTextSubject);
        EditText courseNum = (EditText) findViewById(R.id.editTextCourseNum);
        Spinner yearSpinner = (Spinner) findViewById(R.id.year_spinner);
        Spinner quarterSpinner = (Spinner) findViewById(R.id.quarter_spinner);

        String yearText = yearSpinner.getSelectedItem().toString();
        String quarterText = quarterSpinner.getSelectedItem().toString();
        String subjectText = subject.getText().toString();
        String courseNumText = courseNum.getText().toString();
        int newCourseId = db.coursesDao().count() + 1;
        Course newCourse = new Course(newCourseId, yearText, quarterText, subjectText, courseNumText);

        //Alert if all fields not filled out
        if(!filledOut(newCourse)) {
            showAlert(this,"Please fill out all fields!");
        }
        //Alert if duplicate entry
        else if(duplicateEntry(newCourse)) {
            showAlert(this,"Course already entered!");
        }
        //Else if all good, then add to the list
        else {
            db.coursesDao().insert(newCourse);
            coursesViewAdapter.addCourse(newCourse);
        }
    }

    // TODO: Implement OnDoneBtnClicked (move to the next screen)
    public void onDoneBtnClicked(View view) {
        //If no added courses, give alert
        if(coursesViewAdapter.getItemCount() == 0) {
            showAlert(this,"Please enter at least one course!");
        }
        //Otherwise, save and go to next screen
        else {
            //Replace nextScreen with story 5 class
            //Intent intent = new Intent(this,nextScreen.class);
            //startActivity(intent);
        }
    }
}