package com.example.birdsofafeather.model;

public class DummyCourse implements ICourse{
    private final int id;
    private final String year;
    private final String quarter;
    private final String subject;
    private final String courseNum;

    public DummyCourse(int id, String year, String quarter, String subject, String courseNum){
        this.id= id;
        this.year = year;
        this.quarter = quarter;
        this.subject = subject;
        this.courseNum = courseNum;
    }

    @Override
    public int getId(){return id;}

    @Override
    public String getYear(){
        return year;
    }

    @Override
    public String getQuarter(){
        return quarter;
    }

    @Override
    public String getSubject(){
        return subject;
    }

    @Override
    public String getCourseNum(){
        return courseNum;
    }

}
