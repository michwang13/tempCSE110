package com.example.birdsofafeather;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.birdsofafeather.model.ICourse;
import com.example.birdsofafeather.model.db.Course;

import java.util.List;

public class CoursesViewAdapter extends RecyclerView.Adapter<CoursesViewAdapter.ViewHolder> {
    private final List<Course> courses;

    public CoursesViewAdapter(List<Course> courses) {
        super();
        this.courses = courses;
    }

    @NonNull
    @Override
    public CoursesViewAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater
                .from(parent.getContext())
                .inflate(R.layout.courses_list_row, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CoursesViewAdapter.ViewHolder holder, int position) {
        holder.setPerson(courses.get(position));
    }

    @Override
    public int getItemCount() {
        return this.courses.size();
    }

    public void addCourse(Course course){
        this.courses.add(course);
        this.notifyItemInserted(this.courses.size()-1);
    }


    public static class ViewHolder
            extends RecyclerView.ViewHolder
            implements View.OnClickListener {
        private final TextView courseNameView;
        private Course course;

        ViewHolder(View itemView) {
            super(itemView);
            this.courseNameView = itemView.findViewById(R.id.courses_list_row_name);
            itemView.setOnClickListener(this);
        }

        public void setPerson(Course course) {
            this.course = course;
            String courseDescription = course.getYear()+ " - " +course.getQuarter()+ " - " +course.getSubject()+ " - " +course.getCourseNum();
            this.courseNameView.setText(courseDescription);
        }

        // No need to handle onClick BUT DON'T DELETE. Unless we can delete "implement View.OnClickListener" (Michael will do it later)
        @Override
        public void onClick(View view) {
//            Context context = view.getContext();
//            Intent intent = new Intent(context, PersonDetailActivity.class);
//            intent.putExtra("person_id",this.person.getId());
//            context.startActivity(intent);
        }
    }
}

