package com.example.birdsofafeather;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.birdsofafeather.model.DummyCourse;
import com.example.birdsofafeather.model.ICourse;
import com.example.birdsofafeather.model.db.AppDatabase;
import com.example.birdsofafeather.model.db.Course;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    protected RecyclerView coursesRecyclerView;
    protected RecyclerView.LayoutManager coursesLayoutManager;
    protected CoursesViewAdapter coursesViewAdapter;

    private ICourse[] data = {
            new DummyCourse(0, "2001", "Winter", "Software Engineering", "CSE110"),
            new DummyCourse(1, "2001", "Spring", "Design and Analysis of Algorithms", "CSE101"),
            new DummyCourse(2, "2001", "Fall", "Econ", "ECON1")};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AppDatabase db = AppDatabase.singleton(getApplicationContext());
        List<? extends ICourse> courses = db.coursesDao().getAll();


        //Set up the recycler view to show our database contents.
        coursesRecyclerView = findViewById(R.id.courses_view);

        coursesLayoutManager = new LinearLayoutManager(this);
        coursesRecyclerView.setLayoutManager(coursesLayoutManager);

        coursesViewAdapter = new CoursesViewAdapter((List<Course>) courses);
        coursesRecyclerView.setAdapter(coursesViewAdapter);


    }
}